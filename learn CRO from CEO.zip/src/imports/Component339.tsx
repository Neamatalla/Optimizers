import svgPaths from "./svg-gp63fi4o5e";
import imgLearnCroFromOurCeo from "figma:asset/fa195735dddcfaa77f24c9c9f14edf739189de22.png";
import imgScreenshot20250924At120529Am1 from "figma:asset/8a7a6e8497a40fb655644c168414324ab7ecaa93.png";
import { imgGroup, imgGroup1, imgGroup2, imgGroup3 } from "./svg-mlxr0";

function Group1() {
  return (
    <div className="absolute inset-[49.79%_-16.71%_11.67%_66.6%] mask-position-[21.416px_7.654px,_29.041px_14.602px]" data-name="Group" style={{ maskImage: `url('${imgGroup}'), url('${imgGroup1}')` }}>
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 188.194 157.912">
        <g id="Group" opacity="0.6">
          <path d={svgPaths.p267f0080} id="Vector" stroke="url(#paint0_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p1fe03480} id="Vector_2" stroke="url(#paint1_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p1fe03480} id="Vector_3" stroke="url(#paint2_linear_1_175)" strokeLinecap="round" strokeWidth="0.284186" />
          <path d={svgPaths.p31405380} id="Vector_4" stroke="url(#paint3_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p3263bef0} id="Vector_5" stroke="url(#paint4_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p3263bef0} id="Vector_6" stroke="url(#paint5_linear_1_175)" strokeLinecap="round" strokeWidth="0.284186" />
          <path d={svgPaths.p1453ec80} id="Vector_7" stroke="url(#paint6_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p34611a80} id="Vector_8" stroke="url(#paint7_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p20db5d00} id="Vector_9" stroke="url(#paint8_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p20db5d00} id="Vector_10" stroke="url(#paint9_linear_1_175)" strokeLinecap="round" strokeWidth="0.284186" />
          <path d={svgPaths.p8297100} id="Vector_11" stroke="url(#paint10_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p162d9780} id="Vector_12" stroke="url(#paint11_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p1c227580} id="Vector_13" stroke="url(#paint12_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p81b1280} id="Vector_14" stroke="url(#paint13_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p185db1c0} id="Vector_15" stroke="url(#paint14_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p1b036c00} id="Vector_16" stroke="url(#paint15_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p26465600} id="Vector_17" stroke="url(#paint16_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p26465600} id="Vector_18" stroke="url(#paint17_linear_1_175)" strokeLinecap="round" strokeWidth="0.284186" />
          <path d={svgPaths.p1b3d6760} id="Vector_19" stroke="url(#paint18_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p3cec6970} id="Vector_20" stroke="url(#paint19_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p3cec6970} id="Vector_21" stroke="url(#paint20_linear_1_175)" strokeLinecap="round" strokeOpacity="0.8" strokeWidth="0.284186" />
          <path d={svgPaths.p1ec7c3b0} id="Vector_22" stroke="url(#paint21_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p8c4e600} id="Vector_23" stroke="url(#paint22_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p1447e00} id="Vector_24" stroke="url(#paint23_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p31636da0} id="Vector_25" stroke="url(#paint24_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p31636da0} id="Vector_26" stroke="url(#paint25_linear_1_175)" strokeLinecap="round" strokeWidth="0.284186" />
          <path d={svgPaths.p1d8f4880} id="Vector_27" stroke="url(#paint26_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p2c7b0b00} id="Vector_28" stroke="url(#paint27_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p28058000} id="Vector_29" stroke="url(#paint28_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p28058000} id="Vector_30" stroke="url(#paint29_linear_1_175)" strokeLinecap="round" strokeWidth="0.284186" />
          <path d={svgPaths.p18a08380} id="Vector_31" stroke="url(#paint30_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p36ff1a80} id="Vector_32" stroke="url(#paint31_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p36ff1a80} id="Vector_33" stroke="url(#paint32_linear_1_175)" strokeLinecap="round" strokeWidth="0.284186" />
          <path d={svgPaths.p2bd53260} id="Vector_34" stroke="url(#paint33_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p2cd38100} id="Vector_35" stroke="url(#paint34_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p27906d00} id="Vector_36" stroke="url(#paint35_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p376ff200} id="Vector_37" stroke="url(#paint36_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p2bf2b280} id="Vector_38" stroke="url(#paint37_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p1de02000} id="Vector_39" stroke="url(#paint38_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.pbe32700} id="Vector_40" stroke="url(#paint39_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p2fff6d00} id="Vector_41" stroke="url(#paint40_linear_1_175)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.284186" />
          <path d={svgPaths.p2fff6d00} id="Vector_42" stroke="url(#paint41_linear_1_175)" strokeLinecap="round" strokeOpacity="0.8" strokeWidth="0.284186" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_175" x1="94.4389" x2="94.4389" y1="41.326" y2="55.9282">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_175" x1="95.464" x2="95.464" y1="37.5836" y2="52.1858">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint2_linear_1_175" x1="104.354" x2="81.4331" y1="32.9478" y2="56.2544">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint3_linear_1_175" x1="94.0973" x2="94.0973" y1="33.8394" y2="48.4416">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint4_linear_1_175" x1="95.1222" x2="95.1222" y1="30.0963" y2="44.6985">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint5_linear_1_175" x1="96.6514" x2="95.4709" y1="24.5646" y2="42.056">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint6_linear_1_175" x1="93.9265" x2="93.9265" y1="26.3482" y2="40.9504">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint7_linear_1_175" x1="94.6099" x2="94.6099" y1="22.606" y2="37.2082">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint8_linear_1_175" x1="93.9265" x2="93.9265" y1="18.8609" y2="33.4631">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint9_linear_1_175" x1="87.8697" x2="97.983" y1="13.4803" y2="28.0495">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint10_linear_1_175" x1="94.6099" x2="94.6099" y1="15.1187" y2="29.7209">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint11_linear_1_175" x1="95.1222" x2="95.1222" y1="11.3736" y2="25.9758">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint12_linear_1_175" x1="93.414" x2="93.414" y1="7.62927" y2="22.2315">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint13_linear_1_175" x1="94.7806" x2="94.7806" y1="3.88519" y2="18.4874">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint14_linear_1_175" x1="92.0473" x2="92.0473" y1="0.142093" y2="14.7443">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint15_linear_1_175" x1="119.038" x2="119.038" y1="45.0701" y2="59.6723">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint16_linear_1_175" x1="121.43" x2="121.43" y1="48.8151" y2="63.4173">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint17_linear_1_175" x1="129.002" x2="120.943" y1="45.8789" y2="65.6852">
            <stop stopOpacity="0.5" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint18_linear_1_175" x1="123.821" x2="123.821" y1="52.5592" y2="67.1614">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint19_linear_1_175" x1="101.272" x2="101.272" y1="90.7476" y2="105.35">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint20_linear_1_175" x1="78.0105" x2="109.872" y1="90.7787" y2="109.416">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint21_linear_1_175" x1="100.589" x2="100.589" y1="94.4937" y2="109.096">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint22_linear_1_175" x1="100.93" x2="100.93" y1="98.2389" y2="112.841">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint23_linear_1_175" x1="100.247" x2="100.247" y1="101.983" y2="116.585">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint24_linear_1_175" x1="100.76" x2="100.76" y1="105.725" y2="120.328">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint25_linear_1_175" x1="91.1055" x2="112.425" y1="105.841" y2="122.979">
            <stop stopOpacity="0.5" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint26_linear_1_175" x1="101.443" x2="101.443" y1="109.471" y2="124.074">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint27_linear_1_175" x1="100.76" x2="100.76" y1="113.214" y2="127.817">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint28_linear_1_175" x1="101.443" x2="101.443" y1="116.959" y2="131.561">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint29_linear_1_175" x1="90.4891" x2="136.745" y1="124.313" y2="141.849">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint30_linear_1_175" x1="98.5387" x2="98.5387" y1="120.702" y2="135.304">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint31_linear_1_175" x1="96.8306" x2="96.8306" y1="124.448" y2="139.05">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint32_linear_1_175" x1="72.9271" x2="93.5382" y1="120.335" y2="143.599">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint33_linear_1_175" x1="94.7806" x2="94.7806" y1="128.192" y2="142.794">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint34_linear_1_175" x1="92.0476" x2="92.0476" y1="131.936" y2="146.538">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint35_linear_1_175" x1="90.8515" x2="90.8515" y1="135.681" y2="150.283">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint36_linear_1_175" x1="89.1432" x2="89.1432" y1="139.424" y2="154.027">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint37_linear_1_175" x1="86.9225" x2="86.9225" y1="143.168" y2="157.77">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint38_linear_1_175" x1="103.664" x2="103.664" y1="87.0045" y2="101.607">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint39_linear_1_175" x1="121.43" x2="121.43" y1="83.2603" y2="97.8625">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint40_linear_1_175" x1="123.821" x2="123.821" y1="79.5182" y2="94.1204">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint41_linear_1_175" x1="94.6484" x2="128.561" y1="78.5601" y2="98.6294">
            <stop stopOpacity="0.5" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0.5" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function ClipPathGroup() {
  return (
    <div className="absolute contents inset-[53.36%_-12.43%_13.32%_74.34%]" data-name="Clip path group">
      <Group1 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents inset-[53.36%_-12.43%_13.32%_74.34%]" data-name="Group">
      <ClipPathGroup />
    </div>
  );
}

function MaskGroup() {
  return (
    <div className="absolute contents inset-[52.08%_-14.07%_11.3%_73.07%]" data-name="Mask group">
      <Group />
    </div>
  );
}

function Group3() {
  return (
    <div className="mask-position-[7.077px_7.667px,_16.083px_14.625px] relative size-full" data-name="Group" style={{ maskImage: `url('${imgGroup2}'), url('${imgGroup3}')` }}>
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 188.488 158.159">
        <g id="Group" opacity="0.6">
          <path d={svgPaths.p3757b900} id="Vector" stroke="url(#paint0_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.pde98200} id="Vector_2" stroke="url(#paint1_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.pde98200} id="Vector_3" stroke="url(#paint2_linear_1_125)" strokeLinecap="round" strokeWidth="0.28463" />
          <path d={svgPaths.p10fe0a00} id="Vector_4" stroke="url(#paint3_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p3a3ab100} id="Vector_5" stroke="url(#paint4_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p3a3ab100} id="Vector_6" stroke="url(#paint5_linear_1_125)" strokeLinecap="round" strokeWidth="0.28463" />
          <path d={svgPaths.p2b23e840} id="Vector_7" stroke="url(#paint6_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p3c795c80} id="Vector_8" stroke="url(#paint7_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p23f58480} id="Vector_9" stroke="url(#paint8_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p23f58480} id="Vector_10" stroke="url(#paint9_linear_1_125)" strokeLinecap="round" strokeWidth="0.28463" />
          <path d={svgPaths.p25e26140} id="Vector_11" stroke="url(#paint10_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.pc081ac0} id="Vector_12" stroke="url(#paint11_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p1e735300} id="Vector_13" stroke="url(#paint12_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p6290f00} id="Vector_14" stroke="url(#paint13_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p38887880} id="Vector_15" stroke="url(#paint14_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p1be58980} id="Vector_16" stroke="url(#paint15_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p139ca480} id="Vector_17" stroke="url(#paint16_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p139ca480} id="Vector_18" stroke="url(#paint17_linear_1_125)" strokeLinecap="round" strokeWidth="0.28463" />
          <path d={svgPaths.p3e8acb80} id="Vector_19" stroke="url(#paint18_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p13ae8800} id="Vector_20" stroke="url(#paint19_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p13ae8800} id="Vector_21" stroke="url(#paint20_linear_1_125)" strokeLinecap="round" strokeOpacity="0.8" strokeWidth="0.28463" />
          <path d={svgPaths.p3fea2600} id="Vector_22" stroke="url(#paint21_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.pb6d0140} id="Vector_23" stroke="url(#paint22_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p21bc5500} id="Vector_24" stroke="url(#paint23_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p1a946f40} id="Vector_25" stroke="url(#paint24_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p1a946f40} id="Vector_26" stroke="url(#paint25_linear_1_125)" strokeLinecap="round" strokeWidth="0.28463" />
          <path d={svgPaths.p1733fac0} id="Vector_27" stroke="url(#paint26_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p18b9ae00} id="Vector_28" stroke="url(#paint27_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p2e5fbf40} id="Vector_29" stroke="url(#paint28_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p2e5fbf40} id="Vector_30" stroke="url(#paint29_linear_1_125)" strokeLinecap="round" strokeWidth="0.28463" />
          <path d={svgPaths.p2bbb7080} id="Vector_31" stroke="url(#paint30_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.pe63700} id="Vector_32" stroke="url(#paint31_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.pe63700} id="Vector_33" stroke="url(#paint32_linear_1_125)" strokeLinecap="round" strokeWidth="0.28463" />
          <path d={svgPaths.p27f8fa00} id="Vector_34" stroke="url(#paint33_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p8f39040} id="Vector_35" stroke="url(#paint34_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p38e2f380} id="Vector_36" stroke="url(#paint35_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p20fb7880} id="Vector_37" stroke="url(#paint36_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p31a4bb80} id="Vector_38" stroke="url(#paint37_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p233ff0a0} id="Vector_39" stroke="url(#paint38_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p3a753980} id="Vector_40" stroke="url(#paint39_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p3eb4b400} id="Vector_41" stroke="url(#paint40_linear_1_125)" strokeLinecap="round" strokeOpacity="0.6" strokeWidth="0.28463" />
          <path d={svgPaths.p3eb4b400} id="Vector_42" stroke="url(#paint41_linear_1_125)" strokeLinecap="round" strokeOpacity="0.8" strokeWidth="0.28463" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_125" x1="94.5863" x2="94.5863" y1="41.3911" y2="56.0161">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_125" x1="95.6128" x2="95.6128" y1="37.6423" y2="52.2673">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint2_linear_1_125" x1="104.517" x2="81.56" y1="32.9993" y2="56.3423">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint3_linear_1_125" x1="94.2442" x2="94.2442" y1="33.8913" y2="48.5163">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint4_linear_1_125" x1="95.2706" x2="95.2706" y1="30.1433" y2="44.7683">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint5_linear_1_125" x1="96.8022" x2="95.6199" y1="24.603" y2="42.1217">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint6_linear_1_125" x1="94.073" x2="94.073" y1="26.3904" y2="41.0154">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint7_linear_1_125" x1="94.7572" x2="94.7572" y1="22.6411" y2="37.2661">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint8_linear_1_125" x1="94.0729" x2="94.0729" y1="18.8914" y2="33.5164">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint9_linear_1_125" x1="88.0068" x2="98.1358" y1="13.5024" y2="28.0944">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint10_linear_1_125" x1="94.7573" x2="94.7573" y1="15.1413" y2="29.7663">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint11_linear_1_125" x1="95.2706" x2="95.2706" y1="11.3904" y2="26.0154">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint12_linear_1_125" x1="93.56" x2="93.56" y1="7.64134" y2="22.2663">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint13_linear_1_125" x1="94.9284" x2="94.9284" y1="3.8911" y2="18.5161">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint14_linear_1_125" x1="92.1909" x2="92.1909" y1="0.142315" y2="14.7673">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint15_linear_1_125" x1="119.224" x2="119.224" y1="45.1413" y2="59.7663">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint16_linear_1_125" x1="121.619" x2="121.619" y1="48.8904" y2="63.5154">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint17_linear_1_125" x1="129.204" x2="121.131" y1="45.9496" y2="65.7868">
            <stop stopOpacity="0.5" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint18_linear_1_125" x1="124.014" x2="124.014" y1="52.6413" y2="67.2663">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint19_linear_1_125" x1="101.43" x2="101.43" y1="90.8894" y2="105.514">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint20_linear_1_125" x1="78.1322" x2="110.043" y1="90.9205" y2="109.587">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint21_linear_1_125" x1="100.746" x2="100.746" y1="94.6423" y2="109.267">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint22_linear_1_125" x1="101.088" x2="101.088" y1="98.3935" y2="113.018">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint23_linear_1_125" x1="100.403" x2="100.403" y1="102.141" y2="116.766">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint24_linear_1_125" x1="100.917" x2="100.917" y1="105.891" y2="120.516">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint25_linear_1_125" x1="91.2477" x2="112.6" y1="106.007" y2="123.172">
            <stop stopOpacity="0.5" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint26_linear_1_125" x1="101.601" x2="101.601" y1="109.642" y2="124.267">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint27_linear_1_125" x1="100.917" x2="100.917" y1="113.391" y2="128.016">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint28_linear_1_125" x1="101.601" x2="101.601" y1="117.143" y2="131.768">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint29_linear_1_125" x1="90.6303" x2="136.959" y1="124.509" y2="142.073">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint30_linear_1_125" x1="98.6924" x2="98.6924" y1="120.891" y2="135.516">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint31_linear_1_125" x1="96.9815" x2="96.9815" y1="124.642" y2="139.267">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint32_linear_1_125" x1="73.0407" x2="93.684" y1="120.523" y2="143.824">
            <stop stopOpacity="0" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint33_linear_1_125" x1="94.9284" x2="94.9284" y1="128.392" y2="143.017">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint34_linear_1_125" x1="92.1909" x2="92.1909" y1="132.142" y2="146.767">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint35_linear_1_125" x1="90.9934" x2="90.9934" y1="135.893" y2="150.518">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint36_linear_1_125" x1="89.2823" x2="89.2823" y1="139.641" y2="154.266">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint37_linear_1_125" x1="87.0582" x2="87.0582" y1="143.391" y2="158.016">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint38_linear_1_125" x1="103.825" x2="103.825" y1="87.1413" y2="101.766">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint39_linear_1_125" x1="121.619" x2="121.619" y1="83.3905" y2="98.0155">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint40_linear_1_125" x1="124.014" x2="124.014" y1="79.6435" y2="94.2685">
            <stop offset="0.269131" stopColor="#6AE499" stopOpacity="0.5" />
            <stop offset="0.759615" stopColor="#FDE68A" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint41_linear_1_125" x1="94.7962" x2="128.762" y1="78.6839" y2="98.7845">
            <stop stopOpacity="0.5" />
            <stop offset="0.269131" stopColor="#6AE499" />
            <stop offset="0.759615" stopColor="#FDE68A" />
            <stop offset="1" stopOpacity="0.5" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function ClipPathGroup1() {
  return (
    <div className="absolute contents inset-[53.36%_74.15%_13.26%_-12.29%]" data-name="Clip path group">
      <div className="absolute flex inset-[49.79%_66.39%_11.61%_-16.58%] items-center justify-center">
        <div className="-scale-y-100 flex-none h-[157.874px] rotate-180 w-[188.204px]">
          <Group3 />
        </div>
      </div>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents inset-[53.36%_74.15%_13.26%_-12.29%]" data-name="Group">
      <ClipPathGroup1 />
    </div>
  );
}

function MaskGroup1() {
  return (
    <div className="absolute contents inset-[52.08%_72.87%_11.25%_-13.93%]" data-name="Mask group">
      <Group2 />
    </div>
  );
}

function Frame() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute content-stretch flex flex-col gap-[20px] items-center left-1/2 text-center top-[calc(50%-100.5px)] w-[335px]">
      <p className="bg-center bg-clip-text bg-cover bg-no-repeat font-['Sora:SemiBold',sans-serif] font-semibold leading-[48px] relative shrink-0 text-[26px] text-[transparent] tracking-[-1.04px] w-full" style={{ backgroundImage: `url('${imgLearnCroFromOurCeo}')` }}>
        Learn CRO From Our CEO
      </p>
      <p className="font-['Sora:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.8)] w-full">Get insider insights into the strategies that have generated millions in additional revenue for Gulf-based e-commerce brands</p>
    </div>
  );
}

function Background() {
  return (
    <div className="-translate-x-1/2 absolute backdrop-blur-[8.441px] bg-[#020202] border-[#6ae499] border-[0.352px] border-solid h-[161.074px] left-1/2 overflow-clip rounded-[8.441px] top-[208px] w-[281px]" data-name="Background">
      <div className="-translate-x-1/2 absolute h-[152.84px] left-1/2 rounded-[4.862px] top-[3.87px] w-[272.559px]" data-name="Screenshot 2025-09-24 at 12.05.29 AM 1">
        <div aria-hidden="true" className="absolute inset-0 pointer-events-none rounded-[4.862px]">
          <img alt="" className="absolute max-w-none object-cover rounded-[4.862px] size-full" src={imgScreenshot20250924At120529Am1} />
          <div className="absolute bg-[rgba(0,0,0,0.3)] inset-0 rounded-[4.862px]" />
        </div>
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_1.055px_3.165px_0px_rgba(255,255,255,0.4),inset_0px_8.441px_12.661px_0px_rgba(106,228,153,0.2)]" />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-[#020601] relative size-full" data-name="Component 339">
      <MaskGroup />
      <MaskGroup1 />
      <Frame />
      <Background />
    </div>
  );
}