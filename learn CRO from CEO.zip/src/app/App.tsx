import Component339 from "../imports/Component339";

export default function App() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-black">
      <div className="relative w-[375px] h-[409px] overflow-hidden">
        <Component339 />
      </div>
    </div>
  );
}
