
  # Mobile design layout

  This is a code bundle for Mobile design layout. The original project is available at https://www.figma.com/design/aQiKMZyzGc3y5LuNVGn1r8/Mobile-design-layout.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  