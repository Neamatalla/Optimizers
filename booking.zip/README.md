
  # Create mobile design layout

  This is a code bundle for Create mobile design layout. The original project is available at https://www.figma.com/design/nTKZ07jtQDHOdVq21WOJVq/Create-mobile-design-layout.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  