import imgBookYourFreeStrategySession from "figma:asset/c99f81d2182c6749e9b2c210527ba0ddc78c7cee.png";

function Content1() {
  return (
    <div className="content-stretch flex gap-[9.506px] items-center relative shrink-0 size-[11.883px]" data-name="Content">
      <div className="content-stretch flex flex-col items-center justify-center relative rounded-[10px] shrink-0 size-[11.883px]" data-name="Step Number Small">
        <div aria-hidden="true" className="absolute border-[0.594px] border-solid border-white inset-0 pointer-events-none rounded-[10px]" />
        <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[4.24px] text-center text-white whitespace-nowrap">
          <p className="leading-[4.942px]">1</p>
        </div>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative" data-name="Frame">
      <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[10px] text-center text-white whitespace-nowrap">
        <p className="leading-[12px]">Conversions</p>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] h-[28.231px] items-center relative shrink-0" data-name="Content">
      <Content1 />
      <Frame />
    </div>
  );
}

function StepWrapper() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Step Wrapper">
      <Content />
    </div>
  );
}

function Content3() {
  return (
    <div className="content-stretch flex gap-[9.506px] items-center relative shrink-0 size-[11.883px]" data-name="Content">
      <div className="content-stretch flex flex-col items-center justify-center relative rounded-[10px] shrink-0 size-[11.883px]" data-name="Step Number Small">
        <div aria-hidden="true" className="absolute border-[0.594px] border-[rgba(255,255,255,0.5)] border-solid inset-0 pointer-events-none rounded-[10px]" />
        <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[4.24px] text-[rgba(255,255,255,0.5)] text-center whitespace-nowrap">
          <p className="leading-[4.942px]">2</p>
        </div>
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative" data-name="Frame">
      <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[10px] text-[rgba(255,255,255,0.5)] text-center whitespace-nowrap">
        <p className="leading-[12px]">Objective</p>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] h-[28.231px] items-center relative shrink-0" data-name="Content">
      <Content3 />
      <Frame1 />
    </div>
  );
}

function StepWrapper1() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Step Wrapper">
      <Content2 />
    </div>
  );
}

function Content5() {
  return (
    <div className="content-stretch flex gap-[9.506px] items-center relative shrink-0 size-[11.883px]" data-name="Content">
      <div className="content-stretch flex flex-col items-center justify-center relative rounded-[10px] shrink-0 size-[11.883px]" data-name="Step Number Small">
        <div aria-hidden="true" className="absolute border-[0.594px] border-[rgba(255,255,255,0.5)] border-solid inset-0 pointer-events-none rounded-[10px]" />
        <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[4.24px] text-[rgba(255,255,255,0.5)] text-center whitespace-nowrap">
          <p className="leading-[4.942px]">3</p>
        </div>
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative" data-name="Frame">
      <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[10px] text-[rgba(255,255,255,0.5)] text-center whitespace-nowrap">
        <p className="leading-[12px]">Website</p>
      </div>
    </div>
  );
}

function Content4() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] h-[28.231px] items-center relative shrink-0" data-name="Content">
      <Content5 />
      <Frame2 />
    </div>
  );
}

function StepWrapper2() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Step Wrapper">
      <Content4 />
    </div>
  );
}

function Content7() {
  return (
    <div className="content-stretch flex gap-[9.506px] items-center relative shrink-0 size-[11.883px]" data-name="Content">
      <div className="content-stretch flex flex-col items-center justify-center relative rounded-[10px] shrink-0 size-[11.883px]" data-name="Step Number Small">
        <div aria-hidden="true" className="absolute border-[0.594px] border-[rgba(255,255,255,0.5)] border-solid inset-0 pointer-events-none rounded-[10px]" />
        <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[4.24px] text-[rgba(255,255,255,0.5)] text-center whitespace-nowrap">
          <p className="leading-[4.942px]">4</p>
        </div>
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative" data-name="Frame">
      <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[10px] text-[rgba(255,255,255,0.5)] text-center whitespace-nowrap">
        <p className="leading-[12px]">Contact</p>
      </div>
    </div>
  );
}

function Content6() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] h-[28.231px] items-center relative shrink-0" data-name="Content">
      <Content7 />
      <Frame3 />
    </div>
  );
}

function StepWrapper3() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Step Wrapper">
      <Content6 />
    </div>
  );
}

function Content9() {
  return (
    <div className="content-stretch flex gap-[9.506px] items-center relative shrink-0 size-[11.883px]" data-name="Content">
      <div className="content-stretch flex flex-col items-center justify-center relative rounded-[10px] shrink-0 size-[11.883px]" data-name="Step Number Small">
        <div aria-hidden="true" className="absolute border-[0.594px] border-[rgba(255,255,255,0.5)] border-solid inset-0 pointer-events-none rounded-[10px]" />
        <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[4.24px] text-[rgba(255,255,255,0.5)] text-center whitespace-nowrap">
          <p className="leading-[4.942px]">5</p>
        </div>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative" data-name="Frame">
      <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[10px] text-[rgba(255,255,255,0.5)] text-center whitespace-nowrap">
        <p className="leading-[12px]">Schedule</p>
      </div>
    </div>
  );
}

function Content8() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] h-[28.231px] items-center relative shrink-0" data-name="Content">
      <Content9 />
      <Frame4 />
    </div>
  );
}

function StepWrapper4() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0" data-name="Step Wrapper">
      <Content8 />
    </div>
  );
}

function Stepper() {
  return (
    <div className="content-stretch flex items-start justify-between relative rounded-[3.173px] shrink-0 w-[303px]" data-name="Stepper">
      <StepWrapper />
      <StepWrapper1 />
      <StepWrapper2 />
      <StepWrapper3 />
      <StepWrapper4 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <p className="font-['Sora:SemiBold',sans-serif] font-semibold leading-[20px] relative shrink-0 text-[16px] text-center text-white w-[233px]">Number of conversions per MONTH on average?</p>
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center relative shrink-0">
      <Stepper />
      <Frame5 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0">
      <p className="font-['Sora:Regular',sans-serif] font-normal leading-[17px] relative shrink-0 text-[14px] text-white w-[176px]">Select average:</p>
    </div>
  );
}

function Stroke() {
  return (
    <div className="absolute left-[2.96px] rounded-[98.843px] size-[13.838px] top-[2.96px]" data-name="Stroke">
      <div aria-hidden="true" className="absolute border-[1.5px] border-[rgba(255,255,255,0.6)] border-solid inset-[-1.5px] pointer-events-none rounded-[100.343px]" />
    </div>
  );
}

function AssetsRadio() {
  return (
    <div className="absolute left-0 rounded-[98.843px] size-[19.769px] top-0" data-name="Assets/Radio">
      <Stroke />
    </div>
  );
}

function AssetsCheck() {
  return (
    <div className="relative rounded-[98.843px] shrink-0 size-[19.769px]" data-name="Assets/Check">
      <AssetsRadio />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-start relative shrink-0 w-full">
      <div className="flex flex-[1_0_0] flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] min-h-px min-w-px relative text-[14px] text-white w-full">
        <p className="leading-[24px]">Fewer Than 100</p>
      </div>
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-start relative shrink-0 w-full">
      <AssetsCheck />
      <Frame11 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="bg-[#777] flex-[1_0_0] h-[78px] min-h-px min-w-px relative rounded-[12px]">
      <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-center justify-center p-[16px] relative size-full">
          <Frame12 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.4)] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Stroke1() {
  return (
    <div className="absolute left-[3px] size-[14px] top-[3px]" data-name="Stroke">
      <div className="absolute inset-[-10.71%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 17">
          <g id="Stroke">
            <rect height="15.5" rx="7.75" stroke="var(--stroke-0, #31DA72)" strokeWidth="1.5" width="15.5" x="0.75" y="0.75" />
            <circle cx="8.5" cy="8.5" fill="var(--fill-0, #31DA72)" id="Check" r="5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function AssetsRadio1() {
  return (
    <div className="absolute left-0 rounded-[100px] size-[20px] top-0" data-name="Assets/Radio">
      <Stroke1 />
    </div>
  );
}

function AssetsCheck1() {
  return (
    <div className="relative rounded-[100px] shrink-0 size-[20px]" data-name="Assets/Check">
      <AssetsRadio1 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Sora:Regular',sans-serif] font-normal h-[20px] justify-center leading-[0] relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[24px]">From 100 to 1K</p>
      </div>
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-start relative shrink-0 w-full">
      <AssetsCheck1 />
      <Frame16 />
    </div>
  );
}

function Frame14() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" style={{ backgroundImage: "linear-gradient(90deg, rgba(0, 255, 90, 0.1) 0%, rgba(0, 255, 90, 0.1) 100%), linear-gradient(90deg, rgb(119, 119, 119) 0%, rgb(119, 119, 119) 100%)" }}>
      <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-center justify-center p-[16px] relative w-full">
          <Frame15 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#31da72] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex gap-[12px] items-start relative shrink-0 w-full">
      <Frame13 />
      <Frame14 />
    </div>
  );
}

function Stroke2() {
  return (
    <div className="absolute left-[2.96px] rounded-[98.843px] size-[13.838px] top-[2.96px]" data-name="Stroke">
      <div aria-hidden="true" className="absolute border-[1.5px] border-[rgba(255,255,255,0.6)] border-solid inset-[-1.5px] pointer-events-none rounded-[100.343px]" />
    </div>
  );
}

function AssetsRadio2() {
  return (
    <div className="absolute left-0 rounded-[98.843px] size-[19.769px] top-0" data-name="Assets/Radio">
      <Stroke2 />
    </div>
  );
}

function AssetsCheck2() {
  return (
    <div className="relative rounded-[98.843px] shrink-0 size-[19.769px]" data-name="Assets/Check">
      <AssetsRadio2 />
    </div>
  );
}

function Frame19() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-start relative shrink-0 w-full">
      <div className="flex flex-[1_0_0] flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] min-h-px min-w-px relative text-[14px] text-white w-[115px]">
        <p className="leading-[24px]">From 100 to 10K</p>
      </div>
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-start relative shrink-0 w-full">
      <AssetsCheck2 />
      <Frame19 />
    </div>
  );
}

function Frame17() {
  return (
    <div className="bg-[#777] flex-[1_0_0] h-[78px] min-h-px min-w-px relative rounded-[12px]">
      <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-center justify-center p-[16px] relative size-full">
          <Frame18 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.4)] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Stroke3() {
  return (
    <div className="absolute left-[2.96px] rounded-[98.843px] size-[13.838px] top-[2.96px]" data-name="Stroke">
      <div aria-hidden="true" className="absolute border-[1.5px] border-[rgba(255,255,255,0.6)] border-solid inset-[-1.5px] pointer-events-none rounded-[100.343px]" />
    </div>
  );
}

function AssetsRadio3() {
  return (
    <div className="absolute left-0 rounded-[98.843px] size-[19.769px] top-0" data-name="Assets/Radio">
      <Stroke3 />
    </div>
  );
}

function AssetsCheck3() {
  return (
    <div className="relative rounded-[98.843px] shrink-0 size-[19.769px]" data-name="Assets/Check">
      <AssetsRadio3 />
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-start relative shrink-0 w-full">
      <div className="flex flex-[1_0_0] flex-col font-['Sora:Regular',sans-serif] font-normal justify-center leading-[0] min-h-px min-w-px relative text-[14px] text-white w-full">
        <p className="leading-[24px]">10K+</p>
      </div>
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-start relative shrink-0 w-full">
      <AssetsCheck3 />
      <Frame22 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="bg-[#777] flex-[1_0_0] h-[78px] min-h-px min-w-px relative rounded-[12px]">
      <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-center justify-center p-[16px] relative size-full">
          <Frame21 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.4)] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex gap-[12px] items-start relative shrink-0 w-full">
      <Frame17 />
      <Frame20 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start relative shrink-0 w-full">
      <Frame23 />
      <Frame24 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <Frame9 />
      <Frame7 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center relative shrink-0">
      <Frame6 />
      <Frame8 />
    </div>
  );
}

function Card() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex flex-col items-center justify-center left-1/2 pb-[88px] pt-[36px] px-[12px] rounded-[16px] top-[160px] w-[335px]" data-name="Card" style={{ backgroundImage: "linear-gradient(134.069deg, rgba(255, 255, 255, 0.2) 2.6545%, rgba(255, 255, 255, 0) 44.796%), url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 335 441.23\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(52.988 24.55 -16.16 42.635 155.02 61.526)\\'><stop stop-color=\\'rgba(0,0,0,1)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(0,0,0,1)\\' offset=\\'0.55823\\'/><stop stop-color=\\'rgba(0,0,0,0.3)\\' offset=\\'0.73997\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'1\\'/></radialGradient></defs></svg>'), linear-gradient(88.7383deg, rgb(66, 102, 164) 0.1095%, rgb(146, 235, 180) 63.8%)" }}>
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0)] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Frame10 />
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-16.5px_36.9px_0px_white]" />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-[#020601] relative size-full" data-name="Component 368">
      <p className="-translate-x-1/2 absolute bg-center bg-clip-text bg-cover bg-no-repeat font-['Sora:SemiBold',sans-serif] font-semibold leading-[40px] left-[187.5px] text-[36px] text-[transparent] text-center top-[40px] tracking-[-1.44px] w-[335px]" style={{ backgroundImage: `url('${imgBookYourFreeStrategySession}')` }}>
        Book Your Free Strategy Session
      </p>
      <Card />
    </div>
  );
}