import Component368 from '../imports/Component368';

export default function App() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-[#020601]">
      <div className="w-[375px] h-[641px] relative">
        <Component368 />
      </div>
    </div>
  );
}